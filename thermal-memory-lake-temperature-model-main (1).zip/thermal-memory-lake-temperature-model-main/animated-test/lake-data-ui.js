/* Colab data preparation/import only. Uses the existing model's input loaders. */
(() => {
  'use strict';
  const el = id => document.getElementById(id);
  const rows = el('lakeDataRows'), status = el('lakeDataStatus'), results = el('lakeDataResults');
  const end = new Date(); end.setDate(end.getDate() - 10);
  const localDate = value => `${value.getFullYear()}-${String(value.getMonth()+1).padStart(2,'0')}-${String(value.getDate()).padStart(2,'0')}`;
  el('lakeDataEnd').value = localDate(end);
  el('lakeDataEnd').max = localDate(end);
  el('lakeDataStart').max = localDate(end);
  let imported = [];
  let dataFrequency = 'Daily';
  const tabs = document.createElement('div'); tabs.className = 'action-row'; tabs.setAttribute('role', 'tablist'); tabs.setAttribute('aria-label', 'Lake data frequency');
  ['Daily', 'Monthly', 'Yearly'].forEach(frequency => {
    const button = document.createElement('button'); button.type = 'button'; button.textContent = frequency; button.setAttribute('role', 'tab');
    button.className = frequency === dataFrequency ? 'button button--secondary' : 'button button--ghost'; button.setAttribute('aria-selected', String(frequency === dataFrequency));
    button.addEventListener('click', () => { dataFrequency = frequency; [...tabs.children].forEach(tab => { const selected = tab.textContent === frequency; tab.setAttribute('aria-selected', String(selected)); tab.className = selected ? 'button button--secondary' : 'button button--ghost'; }); });
    tabs.append(button);
  });
  el('lakeDataForm').prepend(tabs);
  let rowCounter = 0;
  function show(message, kind = 'neutral') {
    status.className = `status-box status-box--${kind}`;
    status.textContent = message;
  }
  function save(text, name, type) {
    const url = URL.createObjectURL(new Blob([text], {type}));
    const link = document.createElement('a'); link.href = url; link.download = name;
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  function addRow(name = '', lat = '', lon = '') {
    const row = document.createElement('fieldset');
    row.className = 'lake-data-row';
    const legend = document.createElement('legend'); legend.textContent = 'Lake'; row.append(legend);
    const id = ++rowCounter;
    [['name','Lake name','text',name],['lat','Latitude (°)','number',lat],['lon','Longitude (°)','number',lon]].forEach(([key,label,type,value]) => {
      const wrap = document.createElement('label'); wrap.textContent = label;
      const input = document.createElement('input'); input.type = type; input.name = key;
      input.id = `lake-${id}-${key}`; input.value = value; input.required = true;
      if (type === 'number') { input.step = 'any'; input.min = key === 'lat' ? '-90' : '-180'; input.max = key === 'lat' ? '90' : '180'; }
      else input.maxLength = 80;
      wrap.append(input); row.append(wrap);
    });
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button button--ghost';
    remove.textContent = 'Remove'; remove.setAttribute('aria-label', `Remove lake ${name || id}`);
    remove.addEventListener('click', () => {
      if (rows.children.length === 1) { show('Keep at least one lake.', 'warning'); return; }
      row.remove();
    });
    row.append(remove); rows.append(row);
  }
  addRow('Pangong Tso', 33.818895, 78.605780);
  addRow('Tso Moriri', 32.897510, 78.312963);
  el('addLakeDataRow').addEventListener('click', () => addRow());


  function parseLakeList(text) {
    const records = [];
    let record = [], field = '', quoted = false, closed = false;
    text = text.replace(/^\uFEFF/, '');
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (quoted) {
        if (c === '"') { if (text[i+1] === '"') { field += '"'; i++; } else { quoted = false; closed = true; } }
        else field += c;
      } else if (c === ',' || c === '\n' || c === '\r') {
        record.push(field); field = ''; closed = false;
        if (c !== ',') { if (c === '\r' && text[i+1] === '\n') i++; if (record.some(v => v.trim())) records.push(record); record = []; }
      } else if (c === '"' && !field && !closed) quoted = true;
      else { if (closed || c === '"') throw new Error('Invalid CSV quoting.'); field += c; }
    }
    if (quoted) throw new Error('Unclosed quoted field in CSV.');
    record.push(field); if (record.some(v => v.trim())) records.push(record);
    if (records.length < 2) throw new Error('Include a header and at least one lake.');
    const header = records.shift().map(v => v.trim().toLowerCase());
    const required = ['lake_name', 'latitude', 'longitude'];
    if (header.length !== 3 || required.some(k => header.filter(v => v === k).length !== 1)) throw new Error('CSV columns must be lake_name, latitude, longitude.');
    const seen = new Set();
    return records.map((r, i) => {
      if (r.length !== 3) throw new Error(`CSV data row ${i+1}: expected three columns.`);
      const name = r[header.indexOf('lake_name')].trim();
      const latitude = r[header.indexOf('latitude')].trim(), longitude = r[header.indexOf('longitude')].trim();
      const decimal = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/;
      const lat = Number(latitude), lon = Number(longitude);
      if (!name || name.length > 80 || !decimal.test(latitude) || !decimal.test(longitude) || !Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new Error(`CSV data row ${i+1}: use a lake name and valid latitude/longitude in decimal degrees.`);
      if (seen.has(name.toLowerCase())) throw new Error(`CSV data row ${i+1}: duplicate lake name "${name}".`);
      seen.add(name.toLowerCase());
      return {name, lat, lon};
    });
  }
  const listPanel = document.createElement('div'); listPanel.className = 'subpanel';
  const listTitle = document.createElement('h3'); listTitle.textContent = 'Upload multiple lakes';
  const listHint = document.createElement('p'); listHint.className = 'helper';
  listHint.textContent = 'CSV columns: lake_name, latitude, longitude. Use decimal degrees. Upload replaces the lake entries below; you can edit them before downloading one Colab notebook for the whole list, including 100 or more lakes.';
  const listActions = document.createElement('div'); listActions.className = 'action-row';
  const listLabel = document.createElement('label'); listLabel.className = 'button button--secondary'; listLabel.textContent = 'Upload lake list CSV';
  const listInput = document.createElement('input'); listInput.type = 'file'; listInput.accept = '.csv,text/csv'; listInput.setAttribute('aria-label', 'Upload lake list CSV');
  listLabel.append(listInput);
  const demo = document.createElement('button'); demo.type = 'button'; demo.className = 'button button--ghost'; demo.textContent = 'Download demo lake CSV';
  demo.addEventListener('click', () => save('lake_name,latitude,longitude\nPangong Tso,33.818895,78.605780\nTso Moriri,32.897510,78.312963\n', 'lake_list_demo.csv', 'text/csv;charset=utf-8'));
  listInput.addEventListener('change', async event => {
    const file = event.target.files[0]; if (!file) return;
    try {
      if (file.size > 5000000) throw new Error('Lake list CSV exceeds 5 MB.');
      const lakes = parseLakeList(await file.text());
      rows.replaceChildren(); lakes.forEach(lake => addRow(lake.name, lake.lat, lake.lon));
      show(`Loaded ${lakes.length} lakes from CSV. Choose Daily, Monthly or Yearly and download the prepared Colab notebook.`, 'success');
    } catch (error) { show(`Lake list upload failed: ${error.message} Existing entries were kept.`, 'danger'); }
    finally { event.target.value = ''; }
  });
  listActions.append(listLabel, demo); listPanel.append(listTitle, listHint, listActions); rows.before(listPanel);

  function getConfig() {
    const lakes = [...rows.children].map((row,index) => {
      const name = row.querySelector('[name="name"]').value.trim();
      const latText = row.querySelector('[name="lat"]').value.trim(), lonText = row.querySelector('[name="lon"]').value.trim();
      const lat = Number(latText), lon = Number(lonText);
      if (!name || !latText || !lonText || !Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180) throw new Error('Enter a name and valid coordinates for every lake.');
      return {name, lat, lon, file_stem: name.replace(/[^a-zA-Z0-9_-]/g,'_').replace(/_+/g,'_').replace(/^_|_$/g,'') || `lake_${index+1}`};
    });
    if (new Set(lakes.map(l => l.name.toLowerCase())).size !== lakes.length) throw new Error('Use a different name for each lake.');
    const used = new Set();
    lakes.forEach(lake => { const base = lake.file_stem; let i=2; while(used.has(lake.file_stem.toLowerCase())) lake.file_stem = `${base}_${i++}`; used.add(lake.file_stem.toLowerCase()); });
    const start = el('lakeDataStart').value, finish = el('lakeDataEnd').value;
    if (!start || !finish || start > finish || finish > localDate(end)) throw new Error('Choose a valid date range ending at least 10 days before today.');
    return {start_date: start, end_date: finish, frequency: dataFrequency, lakes};
  }
  const codeCell = source => ({cell_type:'code', execution_count:null, metadata:{}, outputs:[], source});
  function makeNotebook(config, pipeline) {
    // JSON is treated as data by json.loads, never as interpolated Python code.
    const setup = `import json\nfrom pathlib import Path\nCONFIG = json.loads(${JSON.stringify(JSON.stringify(config))})\nOUTPUT_DIR = Path("lake_csv_outputs")\nOUTPUT_DIR.mkdir(exist_ok=True)\n`;
    const run = `
from datetime import datetime, timezone
from tempfile import TemporaryDirectory
from google.colab import files
catalog = pystac_client.Client.open(
    'https://planetarycomputer.microsoft.com/api/stac/v1',
    modifier=planetary_computer.sign_inplace
)
bundle = {'format': 'lake-thermal-memory-data-v1', 'frequency': CONFIG.get('frequency', 'Daily'),
          'start_date': CONFIG['start_date'], 'end_date': CONFIG['end_date'],
          'created_at': datetime.now(timezone.utc).isoformat(), 'lakes': [], 'errors': []}
summary = []
for cfg in CONFIG['lakes']:
    try:
        frequency = CONFIG.get('frequency', 'Daily')
        if frequency == 'Daily':
            df, path = build_lake_file(cfg['name'], cfg, catalog, CONFIG['start_date'], CONFIG['end_date'], OUTPUT_DIR)
        else:
            with TemporaryDirectory(prefix='lake_processing_') as scratch_dir:
                df, _ = build_lake_file(cfg['name'], cfg, catalog, CONFIG['start_date'], CONFIG['end_date'], Path(scratch_dir))
        if CONFIG.get('frequency', 'Daily') != 'Daily':
            period = 'M' if CONFIG['frequency'] == 'Monthly' else 'Y'
            dates = pd.to_datetime(df['date'])
            grouped = df.assign(_period=dates.dt.to_period(period)).groupby('_period')
            columns = ['air_temp_c', 'shortwave_w_m2', 'wind_speed_m_s', 'observed_lst_c']
            df = grouped[columns].mean().round(3)
            df.insert(0, 'date', df.index.to_timestamp().strftime('%Y-%m-%d'))
            df = df.reset_index(drop=True)
            path = OUTPUT_DIR / (cfg['file_stem'] + '_' + CONFIG['frequency'].lower() + '_model_input.csv')
            df.to_csv(path, index=False)
        # Remove only this lake's obsolete generated frequency outputs on reruns.
        for other_frequency in ('daily', 'monthly', 'yearly'):
            if other_frequency != frequency.lower():
                obsolete = OUTPUT_DIR / (cfg['file_stem'] + '_' + other_frequency + '_model_input.csv')
                obsolete.unlink(missing_ok=True)
        bundle['lakes'].append({'name': cfg['name'], 'lat': cfg['lat'], 'lon': cfg['lon'],
            'filename': path.name, 'csv': path.read_text(), 'daily_rows': len(df),
            'observed_lst_values': int(df['observed_lst_c'].notna().sum())})
        summary.append({'lake': cfg['name'], 'daily_rows': len(df),
            'observed_lst_values': int(df['observed_lst_c'].notna().sum()),
            'start_date': df['date'].min(), 'end_date': df['date'].max()})
    except Exception as error:
        print(f"FAILED: {cfg['name']}: {error}")
        bundle['errors'].append({'name': cfg['name'], 'message': str(error)})
print('\\nFINAL SUMMARY')
print(pd.DataFrame(summary).to_string(index=False) if summary else 'No lake completed successfully.')
result_path = OUTPUT_DIR / 'lake_data_results.json'
result_path.write_text(json.dumps(bundle, ensure_ascii=False), encoding='utf-8')
print('\\nReturn to the model and import lake_data_results.json.')
files.download(str(result_path))
# The separate CSV files also remain in lake_csv_outputs in the Colab Files panel.
`;
    return {nbformat:4, nbformat_minor:5, metadata:{colab:{name:'Lake_data_download.ipynb',provenance:[]},kernelspec:{display_name:'Python 3',name:'python3'},language_info:{name:'python'}}, cells:[
      {cell_type:'markdown',metadata:{},source:'# Lake data for the thermal-memory model\n\nYour lakes and dates are already configured. Sign in to Google Colab and choose **Runtime → Run all**. At completion, allow the result download, return to the model and import **lake_data_results.json**. Each lake retains its separate CSV.\n\nThis uses the supplied ERA5 + Landsat pipeline: daily means in Asia/Kolkata, Landsat 8/9 scene cloud <2%, exact pixel sampling, the original temperature conversion, same-date mean and three-decimal rounding. There is no additional QA, water-mask, temperature-range or interpolation filter. A low scene cloud percentage alone does not establish pixel quality.\n'},
      codeCell('%pip -q install pystac-client planetary-computer rasterio shapely pyproj requests pandas numpy tqdm\n'),
      codeCell(setup), codeCell(pipeline), codeCell(run)
    ]};
  }
  let pipelineText = null;
  let pipelineRequest = null;
  function loadPipeline() {
    if (!pipelineRequest) {
      pipelineRequest = fetch('data-download/lake_data.py').then(async response => {
        if (!response.ok) throw new Error('Could not load the data pipeline. Refresh and try again.');
        pipelineText = await response.text();
        return pipelineText;
      }).catch(error => { pipelineRequest = null; throw error; });
    }
    return pipelineRequest;
  }
  // Keep subsequent downloads within the user's click, without an awaited fetch.
  loadPipeline().catch(() => {});
  // A real download link retains the browser's direct user-click download action.
  const oldDownloadButton = el('prepareLakeNotebook');
  const notebookDownload = document.createElement('a');
  notebookDownload.id = oldDownloadButton.id;
  notebookDownload.className = oldDownloadButton.className;
  notebookDownload.textContent = oldDownloadButton.textContent;
  notebookDownload.href = '#';
  notebookDownload.download = 'Lake_data_download.ipynb';
  oldDownloadButton.replaceWith(notebookDownload);
  let notebookUrl = null;
  notebookDownload.addEventListener('click', event => {
    try {
      const config = getConfig();
      if (pipelineText === null) {
        event.preventDefault();
        show('Loading notebook preparation. Please click Download again when ready.');
        loadPipeline().then(() => show('Ready. Click Download prepared Colab notebook.', 'success'))
          .catch(error => show(error.message, 'danger'));
        return;
      }
      const notebook = makeNotebook(config, pipelineText);
      const nextUrl = URL.createObjectURL(new Blob([JSON.stringify(notebook, null, 2)], {type:'application/x-ipynb+json'}));
      if (notebookUrl) {
        const previousUrl = notebookUrl;
        setTimeout(() => URL.revokeObjectURL(previousUrl), 60000);
      }
      notebookUrl = nextUrl;
      notebookDownload.href = nextUrl;
      show(`Notebook ready for ${config.lakes.length} lake(s). Open Colab, upload this notebook and choose Runtime → Run all.`, 'success');
      // Do not preventDefault: the anchor downloads through its native click.
    } catch (error) {
      event.preventDefault();
      show(error.message, 'danger');
    }
  });
  el('lakeDataForm').addEventListener('submit', event => event.preventDefault());

  function validateBundle(bundle) {
    if (!bundle || bundle.format !== 'lake-thermal-memory-data-v1' || !['Daily', 'Monthly', 'Yearly'].includes(bundle.frequency) || !Array.isArray(bundle.lakes)) throw new Error('Choose the lake_data_results.json file produced by the prepared notebook.');
    const columns = 'date,air_temp_c,shortwave_w_m2,wind_speed_m_s,observed_lst_c';
    bundle.lakes.forEach(lake => {
      if (typeof lake.name !== 'string' || !lake.name.trim() || typeof lake.csv !== 'string' || lake.csv.length > 10000000 || lake.csv.replace(/^\uFEFF/,'').split(/\r?\n/,1)[0] !== columns) throw new Error('The result file contains an invalid lake CSV or a changed column format.');
    });
    if (bundle.errors !== undefined && (!Array.isArray(bundle.errors) || bundle.errors.some(e => !e || typeof e.name !== 'string' || typeof e.message !== 'string'))) throw new Error('The result file contains an invalid error summary.');
    return bundle;
  }
  function drawResults(bundle) {
    imported = bundle.lakes;
    results.replaceChildren();
    imported.forEach(lake => {
      const card = document.createElement('article'); card.className = 'subpanel lake-data-result';
      const title = document.createElement('h3'); title.textContent = lake.name;
      const info = document.createElement('p'); info.className = 'helper';
      const lines = lake.csv.trim().split(/\r?\n/).slice(1);
      const observed = lines.filter(line => line.split(',')[4]?.trim()).length;
      info.textContent = `${lines.length} ${bundle.frequency.toLowerCase()} rows · ${observed} observed LST dates`;
      const coordinates = document.createElement('p'); coordinates.className = 'helper'; coordinates.textContent = `Latitude: ${lake.lat} · Longitude: ${lake.lon}`;
      card.append(title,info,coordinates);
      if (observed < 10) { const note = document.createElement('p'); note.className='helper'; note.textContent='Fewer than 10 observed LST values. The existing calibration requirements still apply.'; card.append(note); }
      const actions = document.createElement('div'); actions.className = 'action-row';
      const filename = (typeof lake.filename === 'string' ? lake.filename : `${lake.name}_${bundle.frequency.toLowerCase()}_model_input.csv`).replace(/[^a-zA-Z0-9_.-]/g,'_');
      const download = document.createElement('button'); download.type='button'; download.className='button button--ghost'; download.textContent='Download CSV';
      download.addEventListener('click',()=>save(lake.csv,filename,'text/csv;charset=utf-8'));
      const calibration=document.createElement('button');calibration.type='button';calibration.className='button button--secondary';calibration.textContent='Load into both models';
calibration.addEventListener('click',async()=>{try{const loaded=await window.RestCompare.loadBoth(lake.csv,filename,bundle.frequency);if(loaded){show(lake.name+' loaded into both tabs.','success');window.RestCompare.scrollToTabs();}}catch(err){show('Could not load dataset: '+(err.message||err),'danger')}});
actions.append(download,calibration); card.append(actions); results.append(card);
    });
    (bundle.errors||[]).forEach(error=>{
      const message=document.createElement('p'); message.className='status-box status-box--warning';
      message.textContent=`${error.name}: download failed — ${error.message}`; results.append(message);
    });
    show(imported.length ? `Imported ${imported.length} separate lake dataset(s). Select a lake to download or load.` : 'No lake completed. See the download errors below.', imported.length ? 'success':'warning');
  }
  el('lakeDataBundle').addEventListener('change',async event=>{
    const file=event.target.files[0]; if(!file) return;
    try {
      if(file.size>25000000) throw new Error('Result file exceeds 25 MB. Run fewer lakes per notebook.');
      drawResults(validateBundle(JSON.parse(await file.text())));
    }catch(error){show(`Import failed: ${error.message}`,'danger');}
    finally{event.target.value='';}
  });
})();
